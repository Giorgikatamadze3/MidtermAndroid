package com.example.giorgiapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val button: Button = findViewById(R.id.button)

        val phoneEditText: EditText = findViewById(R.id.phone)

        val smsEditText: EditText = findViewById(R.id.sms)

        val passEditText1: EditText = findViewById(R.id.pass1)
        val passEditText2: EditText = findViewById(R.id.pass2)
        button.setOnClickListener {
            if (isPasswordValid(passEditText1.text.toString()) && isPasswordValid(passEditText2.text.toString()) && isPhoneNumberValid(
                    phoneEditText.text.toString()
                )
                && smsEditText.text.isNotEmpty() && (passEditText1.text.toString() == passEditText2.text.toString())
            ){
                Toast.makeText(this,"ახალ პაროლს მიიღებთ ესემესით",Toast.LENGTH_LONG).show()
            }else{
                Toast.makeText(this,"nah",Toast.LENGTH_LONG).show()
            }
        }
    }

    fun isPhoneNumberValid(phoneNumber: String): Boolean {
        val phonePattern = Patterns.PHONE
        return phonePattern.matcher(phoneNumber).matches()
    }

    fun isPasswordValid(password: String): Boolean {
        val digitPattern = ".*\\d.*"
        return password.length >= 8 && password.matches(Regex(digitPattern))
    }
}